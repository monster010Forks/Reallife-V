﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LiteDbExplorer
{
    public class CmdlineCommands
    {
        public const string Open = "open";
        public const string Focus = "focus";
    }
}
